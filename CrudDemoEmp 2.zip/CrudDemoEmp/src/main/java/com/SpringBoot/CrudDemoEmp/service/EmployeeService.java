package com.SpringBoot.CrudDemoEmp.service;

import com.SpringBoot.CrudDemoEmp.entity.Employee;
import org.apache.catalina.LifecycleState;

import java.util.List;

public interface EmployeeService {

    List<Employee>findAll();

    Employee findbyId(int theId);


    Employee save(Employee theEmployee);

    void deleteBy(int theId);


}
