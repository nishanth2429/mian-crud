package com.SpringBoot.CrudDemoEmp.Dao;

import com.SpringBoot.CrudDemoEmp.entity.Employee;

import java.util.List;

public interface EmployeeDao {
    List<Employee> findAll();


    Employee findbyId(int theId);


    Employee save(Employee theEmployee);

   void deleteBy(int theId);







}
