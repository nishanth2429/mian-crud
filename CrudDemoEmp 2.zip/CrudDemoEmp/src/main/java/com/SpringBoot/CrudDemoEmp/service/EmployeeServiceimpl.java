package com.SpringBoot.CrudDemoEmp.service;

import com.SpringBoot.CrudDemoEmp.Dao.EmployeeDao;
import com.SpringBoot.CrudDemoEmp.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EmployeeServiceimpl implements EmployeeService{

    private EmployeeDao employeeDao;

    @Override
    public List<Employee> findAll() {

        return employeeDao.findAll();
    }

    @Override
    public Employee findbyId(int theId) {


        return employeeDao.findbyId(theId);
    }

    @Override
    @Transactional
    public Employee save(Employee theEmployee) {
        return employeeDao.save(theEmployee);
    }

    @Override
    @Transactional
    public void deleteBy(int theId) {
        employeeDao.deleteBy(theId);


    }

    @Autowired
    public EmployeeServiceimpl(EmployeeDao employeeDao) {
        this.employeeDao = employeeDao;
    }



}
