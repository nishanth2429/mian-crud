package com.SpringBoot.CrudDemoEmp.Rest;


import com.SpringBoot.CrudDemoEmp.Dao.EmployeeDao;
import com.SpringBoot.CrudDemoEmp.entity.Employee;
import com.SpringBoot.CrudDemoEmp.service.EmployeeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class EmployeeRestController {


   private EmployeeService employeeService;

    //inject employee dao
    public EmployeeRestController(  EmployeeService employeeService){
        this.employeeService=employeeService;
    }



    //expose "/employee and return the lis of employees
    @GetMapping("/employee")
    public List<Employee>findAll(){
        return employeeService.findAll();
    }
    //get employee by id
    // add mapping for get /employee/{employeeid}
   @GetMapping("/employee/{employeeId}")
   public Employee getEmployee(@PathVariable int employeeId){
        Employee theemployee=employeeService.findbyId(employeeId);
        if(theemployee==null){
            throw new RuntimeException("employee id not found "+employeeId);

        }
        return theemployee;
   }

   //add a new employee
    @PostMapping("/employee/addemployee")
    public Employee addemployee(@RequestBody Employee theEmployee){

        //also pass an id in json ..setid to 0
        theEmployee.setId(0);

        Employee dbEmployee=employeeService.save(theEmployee);
         return dbEmployee;
    }

    //update a employee
    @PutMapping("/employee/updateemployee")
    public Employee updateemployee(@RequestBody Employee theemployee){
        Employee dbEmployee=employeeService.save(theemployee);

        return dbEmployee;
    }

    //delete an employee

    @DeleteMapping("/employee/{employeeId}")
   public String  deleteById(@PathVariable int employeeId){
        Employee dbemployee=employeeService.findbyId(employeeId);
        //throw exception if null

        if(dbemployee==null){
            throw new RuntimeException("Emplouyee doesnt exist in our database");

        }

        employeeService.deleteBy(employeeId);


        return "deleted the employee with Id-"+employeeId;

    }

}
